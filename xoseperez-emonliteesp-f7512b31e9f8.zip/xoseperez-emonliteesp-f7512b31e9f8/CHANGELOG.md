# EmonLiteESP change log

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

## [0.3.0] 2017-09-30
### Added
- Option to define sampling in milliseconds
- Quick mid point fix based on min/max values
- Using I2Cdevlib-ADS1115

## [0.2.0] 2017-08-15
### Changed
- Precission works in multiples of 1, 2 and 5

### Removed
- setPrecission no longer exists

## [0.1.2] 2017-01-24
### Added
- ADC121 example
- Build examples using PlatformIO

## [0.1.1] 2016-10-07
### Changed
- Do not automatically warm-up

## [0.1.0] 2016-07-30
- Initial working version
